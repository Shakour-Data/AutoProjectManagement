"""
Test suite for AutoProjectManagement
"""
