"""
Test suite for AutoProjectManagement
"""
